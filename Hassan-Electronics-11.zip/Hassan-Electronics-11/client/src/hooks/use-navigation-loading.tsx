import { useEffect } from "react";
import { useLocation } from "wouter";

export function useNavigationLoading() {
  const [location] = useLocation();

  useEffect(() => {
    // Just scroll to top on navigation, no loading
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location]);

  return { isLoading: false };
}