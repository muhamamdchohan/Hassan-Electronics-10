import { useState } from "react";
import { Link } from "wouter";
import { Shield, Clock, Phone, Mail, MapPin, CheckCircle, AlertCircle, FileText, Wrench, Headphones, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function Warranty() {
  const [selectedService, setSelectedService] = useState("");

  const warrantyPeriods = [
    { brand: "Samsung", appliance: "Refrigerators", warranty: "10 Years", coverage: "Compressor + 1 Year Comprehensive" },
    { brand: "LG", appliance: "Refrigerators", warranty: "10 Years", coverage: "Compressor + 1 Year Comprehensive" },
    { brand: "Havells", appliance: "Water Heaters", warranty: "5-7 Years", coverage: "Inner Tank + 2 Years Product" },
    { brand: "Blue Star", appliance: "Water Coolers", warranty: "1-2 Years", coverage: "Comprehensive Warranty" },
    { brand: "Samsung", appliance: "Microwaves", warranty: "1 Year", coverage: "Comprehensive + 10 Years Magnetron" },
    { brand: "Bajaj", appliance: "Geysers", warranty: "2+5 Years", coverage: "Product + Tank Warranty" },
  ];

  const services = [
    {
      id: "installation",
      title: "Professional Installation",
      description: "Expert installation by certified technicians",
      icon: <Wrench className="h-6 w-6" />,
      features: ["Free installation for major appliances", "Same-day service available", "Post-installation testing", "Safety compliance check"]
    },
    {
      id: "repair",
      title: "Repair & Maintenance",
      description: "Quick and reliable repair services",
      icon: <FileText className="h-6 w-6" />,
      features: ["Genuine spare parts only", "90-day service warranty", "Emergency repair support", "Preventive maintenance plans"]
    },
    {
      id: "support",
      title: "Customer Support",
      description: "24/7 customer assistance and guidance",
      icon: <Headphones className="h-6 w-6" />,
      features: ["Multi-language support", "Remote troubleshooting", "Product usage guidance", "Warranty claim assistance"]
    }
  ];

  const faqData = [
    {
      question: "How do I register my appliance for warranty?",
      answer: "You can register your appliance online through our warranty portal, via phone, or by visiting our service center. Keep your purchase receipt as proof of purchase."
    },
    {
      question: "What is covered under warranty?",
      answer: "Warranty covers manufacturing defects, component failures, and functional issues. Physical damage, misuse, and normal wear & tear are not covered."
    },
    {
      question: "How long does a warranty claim take?",
      answer: "Most warranty claims are processed within 24-48 hours. Complex issues may take up to 7 business days depending on parts availability."
    },
    {
      question: "Do you provide on-site service?",
      answer: "Yes, we provide on-site service for major appliances like refrigerators, washing machines, and air conditioners. Smaller appliances may need to be brought to our service center."
    },
    {
      question: "What if my appliance needs replacement?",
      answer: "If your appliance cannot be repaired within the warranty period, we offer replacement subject to terms and conditions. The replacement will have the remaining warranty period."
    }
  ];

  return (
    <div className="container mx-auto px-4 lg:px-6 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Warranty & Support</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Comprehensive warranty coverage and professional support services to keep your appliances running at their best.
        </p>
      </div>

      <Tabs defaultValue="warranty" className="space-y-8">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="warranty">Warranty Information</TabsTrigger>
          <TabsTrigger value="services">Support Services</TabsTrigger>
          <TabsTrigger value="contact">Service Request</TabsTrigger>
        </TabsList>

        {/* Warranty Information Tab */}
        <TabsContent value="warranty" className="space-y-8">
          {/* Key Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="text-center">
              <CardContent className="pt-6">
                <Shield className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-semibold mb-2">Comprehensive Coverage</h3>
                <p className="text-muted-foreground">Full protection against manufacturing defects and component failures.</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <Clock className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-semibold mb-2">Extended Warranty</h3>
                <p className="text-muted-foreground">Up to 10 years warranty on compressors and critical components.</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="pt-6">
                <CheckCircle className="h-12 w-12 mx-auto mb-4 text-primary" />
                <h3 className="text-lg font-semibold mb-2">Genuine Parts</h3>
                <p className="text-muted-foreground">Only authentic manufacturer parts used for all repairs and replacements.</p>
              </CardContent>
            </Card>
          </div>

          {/* Warranty Periods Table */}
          <Card>
            <CardHeader>
              <CardTitle>Warranty Periods by Brand & Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {warrantyPeriods.map((item, index) => (
                  <div key={index} className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{item.brand}</Badge>
                        <span className="font-medium">{item.appliance}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{item.coverage}</p>
                    </div>
                    <div className="text-right mt-2 md:mt-0">
                      <div className="text-lg font-bold text-primary">{item.warranty}</div>
                      <div className="text-sm text-muted-foreground">Warranty Period</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* What's Covered */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  What's Covered
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Manufacturing defects</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Component failures</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Electrical issues</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Performance problems</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Free labor costs</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 mr-2 text-green-500" /> Genuine replacement parts</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-red-600">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  What's Not Covered
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Physical damage</li>
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Water damage</li>
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Misuse or negligence</li>
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Normal wear and tear</li>
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Third-party modifications</li>
                  <li className="flex items-center"><AlertCircle className="h-4 w-4 mr-2 text-red-500" /> Acts of nature</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Support Services Tab */}
        <TabsContent value="services" className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {services.map((service) => (
              <Card key={service.id} className="hover:shadow-lg transition-all duration-300">
                <CardHeader className="text-center">
                  <div className="text-primary mb-4">{service.icon}</div>
                  <CardTitle>{service.title}</CardTitle>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Get in Touch with Our Service Team</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-primary" />
                <div>
                  <div className="font-medium">Phone Support</div>
                  <div className="text-muted-foreground">1-800-HASSAN-1</div>
                  <div className="text-sm text-muted-foreground">24/7 Available</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-primary" />
                <div>
                  <div className="font-medium">Email Support</div>
                  <div className="text-muted-foreground">service@hassan.com</div>
                  <div className="text-sm text-muted-foreground">Response in 2 hours</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-primary" />
                <div>
                  <div className="font-medium">Service Centers</div>
                  <div className="text-muted-foreground">50+ locations</div>
                  <div className="text-sm text-muted-foreground">Find nearest center</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="space-y-2">
                {faqData.map((faq, index) => (
                  <AccordionItem key={index} value={`faq-${index}`} className="border rounded-lg px-4">
                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Service Request Tab */}
        <TabsContent value="contact" className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Request Service Support</CardTitle>
              <p className="text-muted-foreground">
                Fill out the form below and our service team will get back to you within 2 hours.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" placeholder="Enter your full name" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" placeholder="Enter your phone number" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" placeholder="Enter your email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="product">Product Model</Label>
                  <Input id="product" placeholder="e.g., Samsung RF28K9380SG" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="service-type">Service Type</Label>
                <select 
                  className="w-full p-2 border rounded-md"
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                >
                  <option value="">Select service type</option>
                  <option value="warranty">Warranty Claim</option>
                  <option value="repair">Repair Service</option>
                  <option value="installation">Installation</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="consultation">Product Consultation</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Issue Description</Label>
                <Textarea 
                  id="description" 
                  placeholder="Describe the issue you're experiencing or the service you need..."
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Service Address</Label>
                <Textarea 
                  id="address" 
                  placeholder="Enter the address where service is needed..."
                  rows={2}
                />
              </div>

              <Button className="w-full md:w-auto">
                Submit Service Request
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Need Immediate Help?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Button className="w-full" variant="outline">
                    <Phone className="h-4 w-4 mr-2" />
                    Call Service Hotline
                  </Button>
                  <Button className="w-full" variant="outline">
                    <Mail className="h-4 w-4 mr-2" />
                    Email Support Team
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Other Services</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/services">
                  <Button className="w-full" variant="outline">
                    <Wrench className="h-4 w-4 mr-2" />
                    Installation Services
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button className="w-full" variant="outline">
                    <Headphones className="h-4 w-4 mr-2" />
                    General Inquiries
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}