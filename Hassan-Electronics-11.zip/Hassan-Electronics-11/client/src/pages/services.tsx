import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { 
  Wrench, Settings, Phone, ShieldCheck, UserCheck, Package, 
  Calendar, Clock, MapPin, CheckCircle, Star, Send
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Services() {
  const { toast } = useToast();
  const [bookingData, setBookingData] = useState({
    name: "",
    email: "",
    phone: "",
    serviceType: "",
    productType: "",
    preferredDate: "",
    preferredTime: "",
    address: "",
    message: "",
  });

  const services = [
    {
      icon: Wrench,
      title: "Professional Installation",
      description: "Expert installation service for all appliances with proper setup and testing to ensure optimal performance.",
      features: ["Certified technicians", "Proper setup & testing", "Safety compliance", "Equipment protection"],
      price: "Starting from $99",
      duration: "2-4 hours"
    },
    {
      icon: Settings,
      title: "Regular Maintenance",
      description: "Scheduled maintenance services to keep your appliances running efficiently and extend their lifespan.",
      features: ["Preventive maintenance", "Performance optimization", "Early issue detection", "Service records"],
      price: "Starting from $79",
      duration: "1-2 hours"
    },
    {
      icon: Phone,
      title: "24/7 Emergency Repair",
      description: "Round-the-clock emergency repair service for urgent appliance issues and breakdowns.",
      features: ["24/7 availability", "Rapid response", "Emergency diagnostics", "Urgent repairs"],
      price: "Starting from $149",
      duration: "1-3 hours"
    },
    {
      icon: ShieldCheck,
      title: "Warranty Support",
      description: "Comprehensive warranty support and claim assistance for all products with extended warranty options.",
      features: ["Warranty claims", "Extended coverage", "Documentation support", "Replacement assistance"],
      price: "Included with purchase",
      duration: "As needed"
    },
    {
      icon: UserCheck,
      title: "Free Consultation",
      description: "Expert advice on choosing the right appliances for your needs and space requirements.",
      features: ["Product recommendations", "Space planning", "Energy efficiency advice", "Budget planning"],
      price: "Free",
      duration: "30-60 minutes"
    },
    {
      icon: Package,
      title: "Genuine Parts",
      description: "Authentic spare parts and accessories for all major appliance brands with guaranteed compatibility.",
      features: ["Original parts only", "Brand compatibility", "Quality guarantee", "Fast sourcing"],
      price: "Varies by part",
      duration: "1-3 days delivery"
    },
  ];

  const serviceProcess = [
    {
      step: 1,
      title: "Book Service",
      description: "Schedule your service appointment online or by phone at your convenience."
    },
    {
      step: 2,
      title: "Confirmation",
      description: "Receive confirmation with technician details and estimated arrival time."
    },
    {
      step: 3,
      title: "Service Delivery",
      description: "Our certified technician arrives on time and completes the service professionally."
    },
    {
      step: 4,
      title: "Quality Check",
      description: "Service completion verification and customer satisfaction confirmation."
    },
  ];

  const serviceAreas = [
    "Tech City Central", "Electronics District", "Commerce Park", "Innovation Quarter",
    "Business District", "Residential Zones", "Industrial Area", "Shopping Centers"
  ];

  const testimonials = [
    {
      name: "Ahmed Hassan",
      service: "Installation Service",
      rating: 5,
      comment: "Excellent installation service! The technician was professional, punctual, and ensured everything was working perfectly before leaving.",
      date: "2 weeks ago"
    },
    {
      name: "Fatima Ali",
      service: "Emergency Repair",
      rating: 5,
      comment: "My refrigerator broke down on a weekend, but their emergency service team fixed it within 2 hours. Incredible response time!",
      date: "1 month ago"
    },
    {
      name: "Omar Sheikh",
      service: "Maintenance Service",
      rating: 5,
      comment: "Regular maintenance has kept our commercial equipment running smoothly. The team is knowledgeable and thorough.",
      date: "3 weeks ago"
    },
  ];

  const bookingMutation = useMutation({
    mutationFn: async (data: typeof bookingData) => {
      const response = await apiRequest("POST", "/api/bookings", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking request submitted!",
        description: "We'll contact you within 2 hours to confirm your appointment.",
      });
      setBookingData({
        name: "",
        email: "",
        phone: "",
        serviceType: "",
        productType: "",
        preferredDate: "",
        preferredTime: "",
        address: "",
        message: "",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit booking request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    bookingMutation.mutate(bookingData);
  };

  const handleBookingChange = (field: string, value: string) => {
    setBookingData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-background to-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-services-title">
              Professional Appliance Services
            </h1>
            <p className="text-xl text-muted-foreground mb-8" data-testid="text-services-description">
              Comprehensive support from purchase to maintenance. Our expert team ensures your appliances run perfectly for years.
            </p>
            <Button size="lg" className="mr-4" data-testid="button-book-service">
              Book a Service
            </Button>
            <Button variant="outline" size="lg" data-testid="button-emergency-call">
              Emergency Call
            </Button>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-our-services-title">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-our-services-description">
              Professional services designed to keep your appliances running at peak performance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="h-full hover:shadow-lg transition-all duration-300" data-testid={`card-service-${index}`}>
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <service.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl" data-testid="text-service-title">{service.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-center" data-testid="text-service-description">
                    {service.description}
                  </p>
                  
                  <div className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-2" data-testid={`feature-${index}-${featureIndex}`}>
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold" data-testid="text-service-price">{service.price}</span>
                      <Badge variant="secondary" data-testid="badge-service-duration">{service.duration}</Badge>
                    </div>
                    <Button className="w-full" data-testid={`button-book-${index}`}>
                      Book This Service
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-process-title">How It Works</h2>
            <p className="text-lg text-muted-foreground" data-testid="text-process-description">
              Simple and straightforward process to get the service you need.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {serviceProcess.map((step, index) => (
              <div key={index} className="text-center" data-testid={`process-step-${index}`}>
                <div className="w-16 h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  {step.step}
                </div>
                <h3 className="font-semibold text-lg mb-2" data-testid="text-step-title">{step.title}</h3>
                <p className="text-muted-foreground text-sm" data-testid="text-step-description">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Booking Form */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Service Information */}
            <div>
              <h2 className="text-3xl font-bold mb-6" data-testid="text-booking-title">Book a Service</h2>
              <p className="text-muted-foreground mb-8" data-testid="text-booking-description">
                Schedule your service appointment and our team will contact you to confirm the details.
              </p>

              {/* Service Areas */}
              <div className="mb-8">
                <h3 className="font-semibold mb-4" data-testid="text-service-areas-title">Service Areas</h3>
                <div className="grid grid-cols-2 gap-2">
                  {serviceAreas.map((area, index) => (
                    <div key={index} className="flex items-center space-x-2" data-testid={`service-area-${index}`}>
                      <MapPin className="h-4 w-4 text-primary" />
                      <span className="text-sm">{area}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Emergency Hotline</p>
                    <p className="text-muted-foreground">+1 (555) 123-4567</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="font-medium">Service Hours</p>
                    <p className="text-muted-foreground">24/7 Emergency | 8AM-6PM Regular</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Booking Form */}
            <Card>
              <CardHeader>
                <CardTitle data-testid="text-form-booking-title">Schedule Your Service</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBookingSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="booking-name">Full Name *</Label>
                      <Input
                        id="booking-name"
                        type="text"
                        required
                        placeholder="Enter your full name"
                        value={bookingData.name}
                        onChange={(e) => handleBookingChange("name", e.target.value)}
                        data-testid="input-booking-name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="booking-email">Email Address *</Label>
                      <Input
                        id="booking-email"
                        type="email"
                        required
                        placeholder="Enter your email"
                        value={bookingData.email}
                        onChange={(e) => handleBookingChange("email", e.target.value)}
                        data-testid="input-booking-email"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="booking-phone">Phone Number *</Label>
                      <Input
                        id="booking-phone"
                        type="tel"
                        required
                        placeholder="Enter your phone number"
                        value={bookingData.phone}
                        onChange={(e) => handleBookingChange("phone", e.target.value)}
                        data-testid="input-booking-phone"
                      />
                    </div>
                    <div>
                      <Label htmlFor="booking-service">Service Type *</Label>
                      <Select value={bookingData.serviceType} onValueChange={(value) => handleBookingChange("serviceType", value)}>
                        <SelectTrigger data-testid="select-booking-service">
                          <SelectValue placeholder="Select service type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="installation">Installation</SelectItem>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                          <SelectItem value="repair">Repair</SelectItem>
                          <SelectItem value="consultation">Consultation</SelectItem>
                          <SelectItem value="emergency">Emergency</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="booking-product">Product Type</Label>
                    <Select value={bookingData.productType} onValueChange={(value) => handleBookingChange("productType", value)}>
                      <SelectTrigger data-testid="select-booking-product">
                        <SelectValue placeholder="Select product type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="refrigerator">Refrigerator</SelectItem>
                        <SelectItem value="stove">Stove/Cooktop</SelectItem>
                        <SelectItem value="water-heater">Water Heater</SelectItem>
                        <SelectItem value="water-cooler">Water Cooler</SelectItem>
                        <SelectItem value="commercial">Commercial Equipment</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="booking-date">Preferred Date *</Label>
                      <Input
                        id="booking-date"
                        type="date"
                        required
                        value={bookingData.preferredDate}
                        onChange={(e) => handleBookingChange("preferredDate", e.target.value)}
                        data-testid="input-booking-date"
                      />
                    </div>
                    <div>
                      <Label htmlFor="booking-time">Preferred Time *</Label>
                      <Select value={bookingData.preferredTime} onValueChange={(value) => handleBookingChange("preferredTime", value)}>
                        <SelectTrigger data-testid="select-booking-time">
                          <SelectValue placeholder="Select time slot" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="8am-10am">8:00 AM - 10:00 AM</SelectItem>
                          <SelectItem value="10am-12pm">10:00 AM - 12:00 PM</SelectItem>
                          <SelectItem value="12pm-2pm">12:00 PM - 2:00 PM</SelectItem>
                          <SelectItem value="2pm-4pm">2:00 PM - 4:00 PM</SelectItem>
                          <SelectItem value="4pm-6pm">4:00 PM - 6:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="booking-address">Service Address *</Label>
                    <Input
                      id="booking-address"
                      type="text"
                      required
                      placeholder="Enter your full address"
                      value={bookingData.address}
                      onChange={(e) => handleBookingChange("address", e.target.value)}
                      data-testid="input-booking-address"
                    />
                  </div>

                  <div>
                    <Label htmlFor="booking-message">Additional Details</Label>
                    <Textarea
                      id="booking-message"
                      rows={4}
                      placeholder="Describe the issue or any special requirements..."
                      value={bookingData.message}
                      onChange={(e) => handleBookingChange("message", e.target.value)}
                      data-testid="textarea-booking-message"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={bookingMutation.isPending}
                    data-testid="button-submit-booking"
                  >
                    {bookingMutation.isPending ? (
                      "Submitting..."
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Book Service
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Service Testimonials */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" data-testid="text-testimonials-title">What Our Customers Say</h2>
            <p className="text-lg text-muted-foreground" data-testid="text-testimonials-description">
              Real feedback from customers who experienced our professional services.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} data-testid={`card-testimonial-${index}`}>
                <CardContent className="p-6">
                  <div className="flex text-yellow-400 mb-3">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4" data-testid="text-testimonial-comment">
                    "{testimonial.comment}"
                  </p>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-semibold" data-testid="text-testimonial-name">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-testimonial-service">
                        {testimonial.service}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground" data-testid="text-testimonial-date">
                      {testimonial.date}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
