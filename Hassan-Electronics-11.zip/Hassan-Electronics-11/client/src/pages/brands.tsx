import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Star, ArrowRight, Award, Shield, Users, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Product } from "@shared/schema";

export default function Brands() {
  const { data: allProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Get unique brands with their product counts and average ratings
  const brandsData = allProducts.reduce((acc, product) => {
    if (!acc[product.brand]) {
      acc[product.brand] = {
        name: product.brand,
        products: [],
        totalProducts: 0,
        totalRating: 0,
        featuredProducts: 0,
        categories: new Set(),
      };
    }
    
    acc[product.brand].products.push(product);
    acc[product.brand].totalProducts += 1;
    acc[product.brand].totalRating += parseFloat(product.rating || "0");
    if (product.isFeatured) acc[product.brand].featuredProducts += 1;
    acc[product.brand].categories.add(product.category);
    
    return acc;
  }, {} as Record<string, any>);

  const brands = Object.values(brandsData).map((brand: any) => ({
    ...brand,
    averageRating: brand.totalProducts > 0 ? (brand.totalRating / brand.totalProducts).toFixed(1) : "0",
    categories: Array.from(brand.categories),
  })).sort((a, b) => b.totalProducts - a.totalProducts);

  const brandLogos = {
    "Samsung": "🔷",
    "LG": "🔴",
    "Whirlpool": "🌊",
    "Haier": "🏢",
    "Prestige": "⭐",
    "Glen": "🔥",
    "Havells": "⚡",
    "Bajaj": "🏛️",
    "Racold": "💧",
    "AO Smith": "🇺🇸",
    "Blue Star": "❄️",
    "Voltas": "🏭",
    "Usha": "🌟",
  };

  return (
    <div className="container mx-auto px-4 lg:px-6 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Our Trusted Brands</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          We partner with the world's leading electronics manufacturers to bring you 
          the highest quality appliances for your home and business.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">{brands.length}</div>
            <div className="text-sm text-muted-foreground">Premium Brands</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">{allProducts.length}</div>
            <div className="text-sm text-muted-foreground">Products Available</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">25+</div>
            <div className="text-sm text-muted-foreground">Years Experience</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-primary">10K+</div>
            <div className="text-sm text-muted-foreground">Happy Customers</div>
          </div>
        </div>
      </div>

      {/* Brand Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {brands.map((brand) => (
          <Card key={brand.name} className="hover:shadow-lg transition-all duration-300 group">
            <CardHeader className="text-center">
              <div className="text-6xl mb-4">{brandLogos[brand.name as keyof typeof brandLogos] || "🏭"}</div>
              <CardTitle className="text-2xl font-bold">{brand.name}</CardTitle>
              <div className="flex items-center justify-center space-x-2">
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="ml-1 font-medium">{brand.averageRating}</span>
                </div>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{brand.totalProducts} products</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {brand.categories.map((category: string) => (
                  <Badge key={category} variant="secondary" className="text-xs">
                    {category.replace('-', ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                  </Badge>
                ))}
              </div>
              
              {brand.featuredProducts > 0 && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Award className="h-4 w-4 mr-2" />
                  {brand.featuredProducts} featured products
                </div>
              )}

              <Link href={`/products?search=${encodeURIComponent(brand.name)}`}>
                <Button className="w-full group-hover:shadow-md transition-all">
                  View Products
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Why Choose Our Brands Section */}
      <div className="bg-muted/50 rounded-lg p-8 mb-12">
        <h2 className="text-3xl font-bold text-center mb-8">Why Choose Our Brand Partners?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <Shield className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">Guaranteed Quality</h3>
            <p className="text-muted-foreground">
              All our brand partners undergo rigorous quality checks and maintain international standards.
            </p>
          </div>
          <div className="text-center">
            <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">Trusted Worldwide</h3>
            <p className="text-muted-foreground">
              These brands are trusted by millions of customers globally for their reliability and performance.
            </p>
          </div>
          <div className="text-center">
            <TrendingUp className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2">Innovation Leaders</h3>
            <p className="text-muted-foreground">
              Our partners continuously innovate to bring you the latest technology and energy-efficient solutions.
            </p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">Ready to Explore Our Products?</h2>
        <p className="text-muted-foreground mb-6">
          Browse through our extensive collection of premium appliances from these trusted brands.
        </p>
        <div className="space-x-4">
          <Link href="/products">
            <Button size="lg">
              Browse All Products
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
          <Link href="/contact">
            <Button variant="outline" size="lg">
              Get Expert Advice
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}