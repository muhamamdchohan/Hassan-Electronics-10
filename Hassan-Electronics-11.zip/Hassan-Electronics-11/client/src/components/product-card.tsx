import { useState } from "react";
import { Link } from "wouter";
import { Star, Heart, Eye, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/hooks/use-cart";
import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const { addToCart, isAddingToCart } = useCart();

  const discount = product.discount || 0;
  const rating = parseFloat(product.rating || "0");

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart({ productId: product.id });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsWishlisted(!isWishlisted);
  };

  return (
    <Card className="group hover:shadow-lg transition-all duration-300" data-testid={`card-product-${product.id}`}>
      <div className="aspect-square overflow-hidden relative">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isFeatured && (
            <Badge className="bg-primary text-primary-foreground" data-testid="badge-bestseller">
              Best Seller
            </Badge>
          )}
          {product.isNew && (
            <Badge variant="secondary" data-testid="badge-new">
              New Arrival
            </Badge>
          )}
          {discount > 0 && (
            <Badge variant="destructive" data-testid="badge-discount">
              {discount}% off
            </Badge>
          )}
        </div>

        {/* Action Buttons */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleWishlist}
            className="w-8 h-8 p-0 rounded-full bg-background/80 hover:bg-background"
            data-testid="button-wishlist"
          >
            <Heart className={`h-4 w-4 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
          </Button>
          <Link href={`/products/${product.id}`}>
            <Button
              variant="secondary"
              size="sm"
              className="w-8 h-8 p-0 rounded-full bg-background/80 hover:bg-background"
              data-testid="button-view-product"
            >
              <Eye className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      <CardContent className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-2" data-testid="text-product-name">
          {product.name}
        </h3>
        
        {/* Rating */}
        <div className="flex items-center space-x-2 mb-2">
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${i < Math.floor(rating) ? "fill-current" : ""}`}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground" data-testid="text-review-count">
            ({product.reviewCount} reviews)
          </span>
        </div>

        {/* Price */}
        <div className="flex items-center space-x-2 mb-3">
          <span className="text-2xl font-bold text-primary" data-testid="text-price">
            ${product.price}
          </span>
          {product.originalPrice && (
            <>
              <span className="text-sm text-muted-foreground line-through" data-testid="text-original-price">
                ${product.originalPrice}
              </span>
              <span className="text-sm text-green-600 font-medium">
                {discount}% off
              </span>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="flex space-x-2">
          <Button
            onClick={handleAddToCart}
            disabled={!product.inStock || isAddingToCart}
            className="flex-1"
            data-testid="button-add-to-cart"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            {isAddingToCart ? "Adding..." : "Add to Cart"}
          </Button>
        </div>

        {!product.inStock && (
          <p className="text-destructive text-sm mt-2" data-testid="text-out-of-stock">
            Out of Stock
          </p>
        )}
      </CardContent>
    </Card>
  );
}
