import { Link } from "wouter";
import { Zap, Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Footer() {
  const productLinks = [
    { name: "Refrigerators", href: "/products?category=refrigerators" },
    { name: "Cooking Equipment", href: "/products?category=cooking" },
    { name: "Water Heaters", href: "/products?category=water-heating" },
    { name: "Water Coolers", href: "/products?category=water-cooling" },
    { name: "Commercial Equipment", href: "/products?category=commercial" },
  ];

  const serviceLinks = [
    { name: "Installation", href: "/services#installation" },
    { name: "Maintenance", href: "/services#maintenance" },
    { name: "Repair", href: "/services#repair" },
    { name: "Warranty Support", href: "/services#warranty" },
    { name: "Consultation", href: "/services#consultation" },
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
  ];

  return (
    <footer className="bg-secondary text-secondary-foreground py-12">
      <div className="container mx-auto px-4 lg:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Zap className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold">Hassan Electronics</span>
            </div>
            <p className="text-secondary-foreground/80 mb-4">
              Your trusted partner for premium home and commercial appliances with professional installation and maintenance services.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <Button
                  key={social.label}
                  variant="ghost"
                  size="sm"
                  asChild
                  className="w-8 h-8 p-0 bg-primary/10 hover:bg-primary hover:text-primary-foreground rounded-full"
                  data-testid={`link-social-${social.label.toLowerCase()}`}
                >
                  <a href={social.href} aria-label={social.label}>
                    <social.icon className="h-4 w-4" />
                  </a>
                </Button>
              ))}
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Products</h4>
            <ul className="space-y-2 text-secondary-foreground/80">
              {productLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href} 
                    className="hover:text-primary transition-colors"
                    data-testid={`link-product-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-secondary-foreground/80">
              {serviceLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href} 
                    className="hover:text-primary transition-colors"
                    data-testid={`link-service-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-secondary-foreground/80">
              <li className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span data-testid="text-address">123 Electronics Street, Tech City</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span data-testid="text-phone">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span data-testid="text-email">info@hassanelectronics.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <span data-testid="text-hours">Mon-Sat: 9AM-7PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-secondary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-secondary-foreground/60">
            &copy; 2024 Hassan Electronics. All rights reserved. |{" "}
            <Link href="/privacy" className="hover:text-primary transition-colors" data-testid="link-privacy">
              Privacy Policy
            </Link>{" "}
            |{" "}
            <Link href="/terms" className="hover:text-primary transition-colors" data-testid="link-terms">
              Terms of Service
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
