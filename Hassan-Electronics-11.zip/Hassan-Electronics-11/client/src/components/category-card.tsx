import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface CategoryCardProps {
  category: {
    id: string;
    name: string;
    icon: string;
    image?: string;
    productCount?: number;
    description?: string;
  };
}

export function CategoryCard({ category }: CategoryCardProps) {
  const defaultImages = {
    refrigerators: "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    cooking: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "water-heating": "https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "water-cooling": "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    commercial: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
  };

  const descriptions = {
    refrigerators: "Single door, double door, side-by-side, and commercial refrigerators from leading brands.",
    cooking: "Gas stoves, electric cooktops, ranges, and professional cooking equipment.",
    "water-heating": "Electric geysers, gas water heaters, and solar water heating systems.",
    "water-cooling": "Electric water coolers, dispensers, fountains, and cooling systems.",
    commercial: "Industrial chillers, commercial refrigerators, freezers, and kitchen equipment.",
  };

  const imageUrl = category.image || defaultImages[category.id as keyof typeof defaultImages];
  const description = category.description || descriptions[category.id as keyof typeof descriptions];

  return (
    <Link href={`/products?category=${category.id}`}>
      <Card className="group hover:shadow-lg transition-all duration-300 cursor-pointer" data-testid={`card-category-${category.id}`}>
        <div className="aspect-[4/3] overflow-hidden">
          <img
            src={imageUrl}
            alt={`${category.name} category`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 mb-3">
            <div className="w-6 h-6 text-primary" data-testid={`icon-${category.id}`}>
              {/* Icon placeholder - would use actual Lucide icon based on category.icon */}
              <div className="w-full h-full bg-primary rounded" />
            </div>
            <h3 className="text-xl font-semibold" data-testid="text-category-name">
              {category.name}
            </h3>
          </div>
          <p className="text-muted-foreground mb-4" data-testid="text-category-description">
            {description}
          </p>
          <div className="flex justify-between items-center">
            {category.productCount && (
              <span className="text-sm text-muted-foreground" data-testid="text-product-count">
                {category.productCount}+ Models
              </span>
            )}
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 font-medium p-0" data-testid="button-view-all">
              <span>View All</span>
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
