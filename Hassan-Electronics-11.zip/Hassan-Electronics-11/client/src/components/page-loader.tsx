import { useEffect, useState } from "react";
import { Zap } from "lucide-react";
import { cn } from "@/lib/utils";

interface PageLoaderProps {
  isLoading: boolean;
}

export function PageLoader({ isLoading }: PageLoaderProps) {
  const [shouldRender, setShouldRender] = useState(isLoading);

  useEffect(() => {
    if (isLoading) {
      setShouldRender(true);
    } else {
      // Delay hiding to allow for smooth animation
      const timer = setTimeout(() => setShouldRender(false), 300);
      return () => clearTimeout(timer);
    }
  }, [isLoading]);

  if (!shouldRender) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm transition-opacity duration-300",
        isLoading ? "opacity-100" : "opacity-0"
      )}
    >
      <div className="flex flex-col items-center space-y-4">
        {/* Animated Logo */}
        <div className="relative">
          <Zap className="h-12 w-12 text-primary animate-pulse" />
          <div className="absolute inset-0 h-12 w-12 border-2 border-primary/30 rounded-full animate-spin" 
               style={{ animationDuration: '1s' }} />
          <div className="absolute inset-1 h-10 w-10 border-2 border-primary/20 rounded-full animate-spin" 
               style={{ animationDuration: '1.5s', animationDirection: 'reverse' }} />
        </div>

        {/* Loading Text */}
        <div className="text-center">
          <h3 className="text-lg font-semibold text-foreground mb-1">Hassan Electronics</h3>
          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
            <span>Loading</span>
            <div className="flex space-x-1">
              <div className="w-1 h-1 bg-primary rounded-full animate-bounce" 
                   style={{ animationDelay: '0ms' }} />
              <div className="w-1 h-1 bg-primary rounded-full animate-bounce" 
                   style={{ animationDelay: '150ms' }} />
              <div className="w-1 h-1 bg-primary rounded-full animate-bounce" 
                   style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-32 h-1 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-primary rounded-full animate-pulse" 
               style={{ 
                 width: isLoading ? '70%' : '100%',
                 transition: 'width 0.5s ease-in-out'
               }} />
        </div>
      </div>
    </div>
  );
}