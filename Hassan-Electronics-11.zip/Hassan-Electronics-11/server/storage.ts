import { type User, type InsertUser, type Product, type InsertProduct, type Contact, type InsertContact, type Booking, type InsertBooking, type CartItem, type InsertCartItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProductById(id: string): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Cart methods
  getCartItems(sessionId: string): Promise<(CartItem & { product: Product })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;

  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;

  // Booking methods
  createBooking(booking: InsertBooking): Promise<Booking>;
  getAllBookings(): Promise<Booking[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private cartItems: Map<string, CartItem>;
  private contacts: Map<string, Contact>;
  private bookings: Map<string, Booking>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.contacts = new Map();
    this.bookings = new Map();
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: Product[] = [
      // REFRIGERATORS
      {
        id: "1",
        name: "Samsung 500L Double Door Refrigerator",
        description: "Energy-efficient double door refrigerator with digital inverter technology and spacious storage compartments.",
        category: "refrigerators",
        brand: "Samsung",
        price: "1299.00",
        originalPrice: "1499.00",
        discount: 13,
        rating: "4.8",
        reviewCount: 125,
        images: [
          "@assets/stock_images/samsung_refrigerator_b2dfa2bf.jpg",
          "@assets/stock_images/samsung_refrigerator_720c29de.jpg", 
          "@assets/stock_images/samsung_refrigerator_8e9341d5.jpg",
          "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Capacity": "500L",
          "Type": "Double Door",
          "Energy Rating": "5 Star",
          "Compressor": "Digital Inverter",
          "Warranty": "10 Years on Compressor"
        },
        features: ["Digital Inverter Technology", "All Around Cooling", "Deodorizer", "LED Lighting"],
        inStock: true,
        stockQuantity: 15,
        tags: ["bestseller", "energy-efficient"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "6",
        name: "LG 630L Side by Side Refrigerator",
        description: "Premium side-by-side refrigerator with InstaView Door-in-Door and smart features.",
        category: "refrigerators",
        brand: "LG",
        price: "1899.00",
        originalPrice: "2199.00",
        discount: 14,
        rating: "4.7",
        reviewCount: 89,
        images: [
          "@assets/stock_images/lg_side_by_side_refr_1100434b.jpg",
          "@assets/stock_images/lg_side_by_side_refr_fcf17db3.jpg",
          "@assets/stock_images/lg_side_by_side_refr_55848706.jpg",
          "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Capacity": "630L",
          "Type": "Side by Side",
          "Energy Rating": "4 Star",
          "Features": "InstaView Door-in-Door",
          "Warranty": "10 Years on Compressor"
        },
        features: ["InstaView Technology", "Multi Air Flow", "Smart Diagnosis", "Door Cooling+"],
        inStock: true,
        stockQuantity: 8,
        tags: ["premium", "smart-features"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "7",
        name: "Whirlpool 340L Triple Door Refrigerator",
        description: "Triple door refrigerator with advanced cooling technology and convertible modes.",
        category: "refrigerators",
        brand: "Whirlpool",
        price: "899.00",
        originalPrice: "1099.00",
        discount: 18,
        rating: "4.5",
        reviewCount: 156,
        images: ["https://images.unsplash.com/photo-1586201375761-83865001e38c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "340L",
          "Type": "Triple Door",
          "Energy Rating": "3 Star",
          "Technology": "6th Sense",
          "Warranty": "10 Years on Compressor"
        },
        features: ["6th Sense Technology", "Adaptive Intelligence", "Active Fresh Zone", "Crystal Clear Storage"],
        inStock: true,
        stockQuantity: 12,
        tags: ["convertible", "adaptive"],
        isFeatured: false,
        isNew: true,
        createdAt: new Date()
      },
      {
        id: "8",
        name: "Haier 195L Single Door Refrigerator",
        description: "Compact single door refrigerator perfect for small families with efficient cooling.",
        category: "refrigerators",
        brand: "Haier",
        price: "449.00",
        originalPrice: "529.00",
        discount: 15,
        rating: "4.3",
        reviewCount: 203,
        images: ["https://images.unsplash.com/photo-1509798739858-d491e10c6b99?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "195L",
          "Type": "Single Door",
          "Energy Rating": "5 Star",
          "Compressor": "Reciprocating",
          "Warranty": "10 Years on Compressor"
        },
        features: ["Space-Optimized Design", "Anti-Bacterial Gasket", "Toughened Glass Shelves", "Eco-Friendly"],
        inStock: true,
        stockQuantity: 20,
        tags: ["compact", "budget-friendly"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },

      // COOKING EQUIPMENT
      {
        id: "2",
        name: "LG 4 Burner Glass Top Gas Stove",
        description: "Premium glass top gas stove with high-efficiency burners and auto-ignition system.",
        category: "cooking",
        brand: "LG",
        price: "399.00",
        originalPrice: "459.00",
        discount: 13,
        rating: "4.6",
        reviewCount: 89,
        images: [
          "@assets/stock_images/gas_stove_cooking_ra_16a5795a.jpg",
          "@assets/stock_images/gas_stove_cooking_ra_c304d661.jpg",
          "@assets/stock_images/gas_stove_cooking_ra_2be12407.jpg",
          "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Burners": "4 Brass Burners",
          "Top Material": "Toughened Glass",
          "Ignition": "Manual",
          "Gas Type": "LPG",
          "Warranty": "2 Years"
        },
        features: ["Toughened Glass Top", "High Efficiency Burners", "Easy to Clean", "Elegant Design"],
        inStock: true,
        stockQuantity: 8,
        tags: ["energy-star"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "9",
        name: "Prestige 3 Burner Steel Gas Stove",
        description: "Durable stainless steel gas stove with efficient brass burners and sturdy design.",
        category: "cooking",
        brand: "Prestige",
        price: "249.00",
        originalPrice: "299.00",
        discount: 17,
        rating: "4.4",
        reviewCount: 178,
        images: ["https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Burners": "3 Brass Burners",
          "Top Material": "Stainless Steel",
          "Ignition": "Manual",
          "Gas Type": "LPG",
          "Warranty": "2 Years"
        },
        features: ["Stainless Steel Body", "High Thermal Efficiency", "Easy Maintenance", "Compact Design"],
        inStock: true,
        stockQuantity: 15,
        tags: ["budget-friendly", "durable"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "10",
        name: "Glen 4 Burner Auto Ignition Gas Stove",
        description: "Advanced gas stove with auto-ignition system and premium finish for modern kitchens.",
        category: "cooking",
        brand: "Glen",
        price: "459.00",
        originalPrice: "549.00",
        discount: 16,
        rating: "4.7",
        reviewCount: 134,
        images: ["https://images.unsplash.com/photo-1556909048-f3d5c1be9c2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Burners": "4 Brass Burners",
          "Top Material": "Toughened Glass",
          "Ignition": "Auto Ignition",
          "Gas Type": "LPG",
          "Warranty": "2 Years"
        },
        features: ["Auto Ignition System", "360° Rotable Nozzles", "Drip Tray", "ISI Certified"],
        inStock: true,
        stockQuantity: 11,
        tags: ["auto-ignition", "premium"],
        isFeatured: true,
        isNew: true,
        createdAt: new Date()
      },
      {
        id: "11",
        name: "Samsung 28L Convection Microwave Oven",
        description: "Multi-functional convection microwave with grill and baking features.",
        category: "cooking",
        brand: "Samsung",
        price: "349.00",
        originalPrice: "399.00",
        discount: 13,
        rating: "4.5",
        reviewCount: 167,
        images: ["https://images.unsplash.com/photo-1574269910814-a859bf98b1e5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "28 Liters",
          "Type": "Convection",
          "Power Output": "900 Watts",
          "Control": "Digital Display",
          "Warranty": "1 Year Comprehensive"
        },
        features: ["Convection Cooking", "Grill Function", "Auto Cook Menus", "Ceramic Enamel Interior"],
        inStock: true,
        stockQuantity: 9,
        tags: ["versatile", "convection"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },

      // WATER HEATING (GEYSERS)
      {
        id: "3",
        name: "Havells 25L Storage Water Heater",
        description: "Energy-efficient storage water heater with advanced safety features and copper tank.",
        category: "water-heating",
        brand: "Havells",
        price: "189.00",
        originalPrice: null,
        discount: 0,
        rating: "4.4",
        reviewCount: 67,
        images: [
          "@assets/stock_images/water_heater_geyser__70d34a6d.jpg",
          "@assets/stock_images/water_heater_geyser__cc9b7d24.jpg",
          "@assets/stock_images/water_heater_geyser__79d37524.jpg",
          "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Capacity": "25 Liters",
          "Type": "Storage",
          "Heating Element": "Copper",
          "Power": "2000W",
          "Warranty": "5 Years on Tank"
        },
        features: ["Instant Heating", "Safety Valve", "Corrosion Resistant", "Energy Efficient"],
        inStock: true,
        stockQuantity: 12,
        tags: ["new-arrival"],
        isFeatured: true,
        isNew: true,
        createdAt: new Date()
      },
      {
        id: "12",
        name: "Bajaj 15L Instant Electric Geyser",
        description: "Compact instant geyser with fast heating and energy-saving technology.",
        category: "water-heating",
        brand: "Bajaj",
        price: "149.00",
        originalPrice: "179.00",
        discount: 17,
        rating: "4.2",
        reviewCount: 145,
        images: ["https://images.unsplash.com/photo-1558618050-1d8c8b86ac5c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "15 Liters",
          "Type": "Instant",
          "Heating Element": "Copper",
          "Power": "3000W",
          "Warranty": "2 Years Product + 5 Years Tank"
        },
        features: ["Instant Hot Water", "Shock Proof Body", "Rust Proof Coating", "ISI Approved"],
        inStock: true,
        stockQuantity: 18,
        tags: ["instant", "compact"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "13",
        name: "Racold 25L Vertical Electric Geyser",
        description: "Premium vertical geyser with titanium+ tank and smart features.",
        category: "water-heating",
        brand: "Racold",
        price: "229.00",
        originalPrice: "269.00",
        discount: 15,
        rating: "4.6",
        reviewCount: 123,
        images: ["https://images.unsplash.com/photo-1558618048-1d8c8b86ac5d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "25 Liters",
          "Type": "Storage Vertical",
          "Tank": "Titanium+ Inner Tank",
          "Power": "2000W",
          "Warranty": "7 Years on Tank"
        },
        features: ["Titanium+ Protection", "Smart Bath Logic", "Digital Display", "High Pressure Withstand"],
        inStock: true,
        stockQuantity: 14,
        tags: ["smart", "titanium"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "14",
        name: "AO Smith 35L Gas Water Heater",
        description: "High-efficiency gas water heater with blue diamond glass lining technology.",
        category: "water-heating",
        brand: "AO Smith",
        price: "299.00",
        originalPrice: "349.00",
        discount: 14,
        rating: "4.8",
        reviewCount: 97,
        images: ["https://images.unsplash.com/photo-1558618047-3c8c76ca7d15?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "35 Liters",
          "Type": "Gas Storage",
          "Technology": "Blue Diamond Glass Lining",
          "Efficiency": "80%",
          "Warranty": "6 Years Tank + 2 Years Product"
        },
        features: ["Blue Diamond Technology", "Advanced Combustion", "Safety Thermocouple", "Low NOx Emissions"],
        inStock: true,
        stockQuantity: 7,
        tags: ["gas", "premium", "eco-friendly"],
        isFeatured: true,
        isNew: true,
        createdAt: new Date()
      },

      // WATER COOLING
      {
        id: "4",
        name: "Blue Star 40L Water Cooler",
        description: "Commercial grade water cooler with high cooling capacity and stainless steel construction.",
        category: "water-cooling",
        brand: "Blue Star",
        price: "599.00",
        originalPrice: "699.00",
        discount: 14,
        rating: "4.7",
        reviewCount: 94,
        images: [
          "@assets/stock_images/water_cooler_dispens_e827d759.jpg",
          "@assets/stock_images/water_cooler_dispens_9af4c701.jpg",
          "@assets/stock_images/water_cooler_dispens_4d9fde94.jpg",
          "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Capacity": "40 Liters",
          "Cooling Type": "Compressor",
          "Material": "Stainless Steel",
          "Power": "150W",
          "Warranty": "1 Year Comprehensive"
        },
        features: ["High Cooling Capacity", "Stainless Steel Body", "Energy Efficient", "Easy Maintenance"],
        inStock: true,
        stockQuantity: 6,
        tags: [],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "15",
        name: "Voltas 20L Table Top Water Cooler",
        description: "Compact table-top water cooler perfect for small offices and homes.",
        category: "water-cooling",
        brand: "Voltas",
        price: "399.00",
        originalPrice: "459.00",
        discount: 13,
        rating: "4.3",
        reviewCount: 176,
        images: ["https://images.unsplash.com/photo-1533090161767-e6ffed986c89?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "20 Liters",
          "Type": "Table Top",
          "Cooling": "Compressor Based",
          "Power": "120W",
          "Warranty": "1 Year"
        },
        features: ["Compact Design", "Fast Cooling", "Energy Efficient", "Rust Resistant"],
        inStock: true,
        stockQuantity: 13,
        tags: ["compact", "table-top"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "16",
        name: "Usha 60L Floor Standing Water Cooler",
        description: "Large capacity floor standing water cooler for commercial use.",
        category: "water-cooling",
        brand: "Usha",
        price: "749.00",
        originalPrice: "849.00",
        discount: 12,
        rating: "4.5",
        reviewCount: 84,
        images: ["https://images.unsplash.com/photo-1533090161767-e6ffed986c90?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "60 Liters",
          "Type": "Floor Standing",
          "Cooling": "Compressor Based",
          "Power": "180W",
          "Warranty": "2 Years"
        },
        features: ["Large Storage", "Heavy Duty Compressor", "Stainless Steel Tank", "Anti-Corrosive Body"],
        inStock: true,
        stockQuantity: 5,
        tags: ["large-capacity", "commercial"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },

      // COMMERCIAL EQUIPMENT
      {
        id: "5",
        name: "Voltas 500L Commercial Deep Freezer",
        description: "High-capacity commercial deep freezer for restaurants and commercial establishments.",
        category: "commercial",
        brand: "Voltas",
        price: "2499.00",
        originalPrice: "2799.00",
        discount: 11,
        rating: "4.5",
        reviewCount: 45,
        images: [
          "@assets/stock_images/commercial_freezer_r_823eba6c.jpg",
          "@assets/stock_images/commercial_freezer_r_27d0c9e0.jpg",
          "@assets/stock_images/commercial_freezer_r_47ee3005.jpg",
          "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
        ],
        specifications: {
          "Capacity": "500 Liters",
          "Type": "Deep Freezer",
          "Temperature Range": "-18°C to -24°C",
          "Defrost": "Manual",
          "Warranty": "2 Years Comprehensive"
        },
        features: ["High Storage Capacity", "Energy Efficient", "Robust Construction", "Temperature Control"],
        inStock: true,
        stockQuantity: 3,
        tags: ["commercial"],
        isFeatured: false,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "17",
        name: "Blue Star 300L Display Freezer",
        description: "Glass top display freezer perfect for ice cream parlors and retail stores.",
        category: "commercial",
        brand: "Blue Star",
        price: "1899.00",
        originalPrice: "2199.00",
        discount: 14,
        rating: "4.6",
        reviewCount: 67,
        images: ["https://images.unsplash.com/photo-1621905251189-08b45d6a269f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "300 Liters",
          "Type": "Display Freezer",
          "Temperature Range": "-15°C to -20°C",
          "Door Type": "Curved Glass",
          "Warranty": "2 Years"
        },
        features: ["Curved Glass Top", "LED Lighting", "Energy Efficient", "Easy Access"],
        inStock: true,
        stockQuantity: 4,
        tags: ["display", "retail"],
        isFeatured: true,
        isNew: false,
        createdAt: new Date()
      },
      {
        id: "18",
        name: "Haier 700L Four Door Commercial Refrigerator",
        description: "Large four-door commercial refrigerator for restaurants and hotels.",
        category: "commercial",
        brand: "Haier",
        price: "3299.00",
        originalPrice: "3699.00",
        discount: 11,
        rating: "4.4",
        reviewCount: 23,
        images: ["https://images.unsplash.com/photo-1584622650111-993a426fbf0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"],
        specifications: {
          "Capacity": "700 Liters",
          "Type": "Four Door Refrigerator",
          "Temperature Range": "2°C to 8°C",
          "Shelves": "Adjustable",
          "Warranty": "3 Years Comprehensive"
        },
        features: ["Four Door Design", "Large Storage", "Commercial Grade", "Temperature Control"],
        inStock: true,
        stockQuantity: 2,
        tags: ["large-capacity", "restaurant"],
        isFeatured: false,
        isNew: true,
        createdAt: new Date()
      }
    ];

    sampleProducts.forEach(product => {
      this.products.set(product.id, product);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.category === category
    );
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.isFeatured
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) =>
        product.name.toLowerCase().includes(lowerQuery) ||
        product.description.toLowerCase().includes(lowerQuery) ||
        product.brand.toLowerCase().includes(lowerQuery) ||
        product.category.toLowerCase().includes(lowerQuery)
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id, 
      originalPrice: insertProduct.originalPrice ?? null,
      discount: insertProduct.discount ?? 0,
      rating: insertProduct.rating ?? "0",
      reviewCount: insertProduct.reviewCount ?? 0,
      stockQuantity: insertProduct.stockQuantity ?? 0,
      tags: insertProduct.tags ?? null,
      isFeatured: insertProduct.isFeatured ?? false,
      isNew: insertProduct.isNew ?? false,
      createdAt: new Date() 
    };
    this.products.set(id, product);
    return product;
  }

  async getCartItems(sessionId: string): Promise<(CartItem & { product: Product })[]> {
    const items = Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );
    
    const itemsWithProducts = [];
    for (const item of items) {
      const product = this.products.get(item.productId);
      if (product) {
        itemsWithProducts.push({ ...item, product });
      }
    }
    
    return itemsWithProducts;
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    // Check if item already exists
    const existingItem = Array.from(this.cartItems.values()).find(
      (item) => item.sessionId === insertItem.sessionId && item.productId === insertItem.productId
    );

    if (existingItem) {
      // Update quantity
      existingItem.quantity += (insertItem.quantity || 1);
      this.cartItems.set(existingItem.id, existingItem);
      return existingItem;
    } else {
      // Create new item
      const id = randomUUID();
      const cartItem: CartItem = { 
        ...insertItem, 
        id, 
        quantity: insertItem.quantity || 1,
        createdAt: new Date() 
      };
      this.cartItems.set(id, cartItem);
      return cartItem;
    }
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (item) {
      item.quantity = quantity;
      this.cartItems.set(id, item);
      return item;
    }
    return undefined;
  }

  async removeFromCart(id: string): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = Array.from(this.cartItems.entries()).filter(
      ([_, item]) => item.sessionId === sessionId
    );
    
    items.forEach(([id]) => {
      this.cartItems.delete(id);
    });
    
    return true;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      phone: insertContact.phone || null,
      status: "pending",
      createdAt: new Date() 
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = randomUUID();
    const booking: Booking = { 
      ...insertBooking, 
      id, 
      productType: insertBooking.productType || null,
      message: insertBooking.message || null,
      status: "pending",
      createdAt: new Date() 
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async getAllBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }
}

export const storage = new MemStorage();
